package mendoza.brayan.pp.progii121.models;

public interface Vacunable {
    boolean vacunar();
    
}
