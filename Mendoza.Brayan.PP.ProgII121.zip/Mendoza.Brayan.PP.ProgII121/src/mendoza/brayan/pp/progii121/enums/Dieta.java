package mendoza.brayan.pp.progii121.enums;

public enum Dieta {
    HERBIVORO,
    CARNIVORO,
    OMNIVORO
}
