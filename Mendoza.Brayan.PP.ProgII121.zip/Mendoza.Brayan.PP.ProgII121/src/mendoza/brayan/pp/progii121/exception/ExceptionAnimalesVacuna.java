package mendoza.brayan.pp.progii121.exception;

public class ExceptionAnimalesVacuna extends RuntimeException{

    public ExceptionAnimalesVacuna(String message) {
        super(message);
    }
}
